#include <map>

#ifndef OPERATIONS_H
#define OPERATIONS_H

//print 1
void print(std::map<std::string, std::map<std::string, std::string>> inventory);

//add 2
std::map<std::string, std::map<std::string, std::string>> add(std::map<std::string, std::map<std::string, std::string>> inventory, std::string file_name);

//subtract 3
std::map<std::string, std::map<std::string, std::string>> subtract(std::map<std::string, std::map<std::string, std::string>> inventory, std::string file_name);

//append 4
std::map<std::string, std::map<std::string, std::string>> append(std::map<std::string, std::map<std::string, std::string>> inventory, std::string file_name);

//remove 5
std::map<std::string, std::map<std::string, std::string>> remove(std::map<std::string, std::map<std::string, std::string>> inventory, std::string file_name);

//sort 6
void sort(std::map<std::string, std::map<std::string, std::string>> inventory, std::string file_name);

//get 7
void get(std::map<std::string, std::map<std::string, std::string>> inventory);

//set 8
std::map<std::string, std::map<std::string, std::string>> set(std::map<std::string, std::map<std::string, std::string>> inventory, std::string file_name);
/* merge is unnecessary bc map overwrites count if duplicate pieces
//merge 9
std::map<std::string, std::map<std::string, std::string>> merge(std::map<std::string, std::map<std::string, std::string>> inventory, std::string file_name);
*/

//4/2/26 9:00am
/*
 std::vector<std::string> search(std::map<std::string, std::map<std::string, std::string>> inventory);
 */

#endif

